import type { KeyEvent, TypingPattern } from '../types';

export function calculateTypingPattern(events: KeyEvent[]): TypingPattern {
  const pattern: TypingPattern = {
    averageSpeed: 0,
    keyPressDistribution: {},
    modifierUsage: {},
    timingPatterns: [],
    specialKeyFrequency: {},
    backspaceFrequency: 0,
    averageWordLength: 0,
    rhythmConsistency: 0,
    modifierFrequency: 0,
    capitalFrequency: 0,
    punctuationFrequency: 0,
    burstSpeed: 0
  };

  if (events.length < 2) return pattern;

  // Calculate timing patterns and average speed
  const intervals = events.slice(1).map((event, i) => event.timeSinceLast);
  pattern.timingPatterns = intervals;
  pattern.averageSpeed = intervals.reduce((a, b) => a + b, 0) / intervals.length;

  // Calculate rhythm consistency (standard deviation of intervals)
  const mean = pattern.averageSpeed;
  const variance = intervals.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / intervals.length;
  pattern.rhythmConsistency = Math.sqrt(variance);

  // Calculate burst speed (average of fastest 20% intervals)
  const sortedIntervals = [...intervals].sort((a, b) => a - b);
  const burstCount = Math.max(1, Math.floor(intervals.length * 0.2));
  pattern.burstSpeed = sortedIntervals.slice(0, burstCount).reduce((a, b) => a + b, 0) / burstCount;

  let currentWord = '';
  let totalWordLength = 0;
  let wordCount = 0;
  let modifierCount = 0;
  let capitalCount = 0;
  let punctuationCount = 0;

  events.forEach(event => {
    if (Object.values(event.modifiers).some(v => v)) {
      modifierCount++;
    }

    if (event.key.length === 1) {
      pattern.keyPressDistribution[event.key] = (pattern.keyPressDistribution[event.key] || 0) + 1;
      
      if (event.key.match(/[A-Z]/)) {
        capitalCount++;
      }

      if (event.key.match(/[.,!?;:'"]/)) {
        punctuationCount++;
      }

      if (event.key === ' ' || event.key === 'Enter') {
        if (currentWord.length > 0) {
          totalWordLength += currentWord.length;
          wordCount++;
          currentWord = '';
        }
      } else {
        currentWord += event.key;
      }
    }

    if (event.key === 'Backspace') {
      pattern.backspaceFrequency++;
      if (currentWord.length > 0) {
        currentWord = currentWord.slice(0, -1);
      }
    }

    Object.entries(event.modifiers).forEach(([key, value]) => {
      if (value) {
        pattern.modifierUsage[key] = (pattern.modifierUsage[key] || 0) + 1;
      }
    });
  });

  if (currentWord.length > 0) {
    totalWordLength += currentWord.length;
    wordCount++;
  }

  pattern.averageWordLength = wordCount > 0 ? totalWordLength / wordCount : 0;
  pattern.modifierFrequency = events.length > 0 ? modifierCount / events.length : 0;
  pattern.capitalFrequency = events.length > 0 ? capitalCount / events.length : 0;
  pattern.punctuationFrequency = events.length > 0 ? punctuationCount / events.length : 0;

  return pattern;
}

export function comparePatterns(pattern1: TypingPattern, pattern2: TypingPattern): number {
  const weights = {
    speed: 0.2,
    wordLength: 0.15,
    rhythm: 0.15,
    modifiers: 0.15,
    capitals: 0.15,
    punctuation: 0.1,
    burst: 0.1
  };

  const speedDiff = Math.abs(pattern1.averageSpeed - pattern2.averageSpeed);
  const speedSimilarity = Math.max(0, 1 - speedDiff / 200);

  const wordLengthDiff = Math.abs(pattern1.averageWordLength - pattern2.averageWordLength);
  const wordLengthSimilarity = Math.max(0, 1 - wordLengthDiff / 5);

  const rhythmDiff = Math.abs(pattern1.rhythmConsistency - pattern2.rhythmConsistency);
  const rhythmSimilarity = Math.max(0, 1 - rhythmDiff / 100);

  const modifierDiff = Math.abs(pattern1.modifierFrequency - pattern2.modifierFrequency);
  const modifierSimilarity = Math.max(0, 1 - modifierDiff);

  const capitalDiff = Math.abs(pattern1.capitalFrequency - pattern2.capitalFrequency);
  const capitalSimilarity = Math.max(0, 1 - capitalDiff);

  const punctuationDiff = Math.abs(pattern1.punctuationFrequency - pattern2.punctuationFrequency);
  const punctuationSimilarity = Math.max(0, 1 - punctuationDiff);

  const burstDiff = Math.abs(pattern1.burstSpeed - pattern2.burstSpeed);
  const burstSimilarity = Math.max(0, 1 - burstDiff / 200);

  return (
    speedSimilarity * weights.speed +
    wordLengthSimilarity * weights.wordLength +
    rhythmSimilarity * weights.rhythm +
    modifierSimilarity * weights.modifiers +
    capitalSimilarity * weights.capitals +
    punctuationSimilarity * weights.punctuation +
    burstSimilarity * weights.burst
  );
}