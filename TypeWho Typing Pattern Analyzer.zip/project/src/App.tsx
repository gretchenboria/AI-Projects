import React, { useState, useRef } from 'react';
import { Save, Trash2, BarChart2, Keyboard, UserCircle2, Users, Brain, PlayCircle, RotateCcw, AlertTriangle, HelpCircle, Sparkles, X, Laptop, Smartphone, Tablet } from 'lucide-react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { motion, AnimatePresence } from 'framer-motion';
import { useFloating, useHover, useInteractions, offset, shift, flip, arrow, FloatingArrow } from '@floating-ui/react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const MINIMUM_SAMPLE_SIZE = 75;

interface KeyEvent {
  key: string;
  code: string;
  timestamp: number;
  timeSinceLast: number;
  modifiers: {
    ctrl: boolean;
    alt: boolean;
    shift: boolean;
    meta: boolean;
  };
}

interface TypingPattern {
  averageSpeed: number;
  keyPressDistribution: { [key: string]: number };
  modifierUsage: { [key: string]: number };
  timingPatterns: number[];
  specialKeyFrequency: { [key: string]: number };
  backspaceFrequency: number;
  averageWordLength: number;
  rhythmConsistency: number;
  modifierFrequency: number;
  capitalFrequency: number;
  punctuationFrequency: number;
  burstSpeed: number;
}

interface UserProfile {
  id: string;
  firstName: string;
  lastName: string;
  samples: KeyEvent[][];
  pattern: TypingPattern;
  createdAt: number;
  device: 'desktop' | 'mobile' | 'tablet';
}

interface PredictionHistory {
  timestamp: number;
  actualUser: string;
  predictedUser: string;
  confidence: number;
  correct: boolean;
  device: 'desktop' | 'mobile' | 'tablet';
}

const SparkleEffect = () => {
  return (
    <motion.div
      className="absolute inset-0 pointer-events-none"
      initial={{ opacity: 0 }}
      animate={{ opacity: [0, 1, 0] }}
      transition={{ duration: 2 }}
    >
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute"
          initial={{
            x: Math.random() * 100 - 50,
            y: Math.random() * 100 - 50,
            scale: 0,
            opacity: 0
          }}
          animate={{
            x: Math.random() * 200 - 100,
            y: Math.random() * 200 - 100,
            scale: [0, 1, 0],
            opacity: [0, 1, 0]
          }}
          transition={{
            duration: 2,
            delay: Math.random() * 0.5,
            ease: "easeOut"
          }}
        >
          <Sparkles className="text-yellow-400 w-4 h-4" />
        </motion.div>
      ))}
    </motion.div>
  );
};

const MatchMeter = ({ confidence }: { confidence: number }) => {
  return (
    <div className="w-full bg-gray-200 rounded-full h-4 mt-4">
      <motion.div
        className="h-full rounded-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"
        initial={{ width: 0 }}
        animate={{ width: `${confidence * 100}%` }}
        transition={{ duration: 1, ease: "easeOut" }}
      />
    </div>
  );
};

type Mode = 'create' | 'predict';

function App() {
  const [mode, setMode] = useState<Mode>('create');
  const [keyEvents, setKeyEvents] = useState<KeyEvent[]>([]);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [lastKeyTime, setLastKeyTime] = useState<number | null>(null);
  const [userProfiles, setUserProfiles] = useState<UserProfile[]>([]);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [predictionResult, setPredictionResult] = useState<string | null>(null);
  const [selfTestResult, setSelfTestResult] = useState<string | null>(null);
  const [predictionHistory, setPredictionHistory] = useState<PredictionHistory[]>([]);
  const [showDashboard, setShowDashboard] = useState(true);
  const [expectedProfile, setExpectedProfile] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showHowItWorks, setShowHowItWorks] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<'desktop' | 'mobile' | 'tablet'>('desktop');
  const textAreaRef = useRef<HTMLTextAreaElement>(null);

  const resetState = () => {
    setKeyEvents([]);
    setStartTime(null);
    setLastKeyTime(null);
    setPredictionResult(null);
    if (textAreaRef.current) {
      textAreaRef.current.value = '';
    }
  };

  const calculateTypingPattern = (events: KeyEvent[]): TypingPattern => {
    const pattern: TypingPattern = {
      averageSpeed: 0,
      keyPressDistribution: {},
      modifierUsage: {},
      timingPatterns: [],
      specialKeyFrequency: {},
      backspaceFrequency: 0,
      averageWordLength: 0,
      rhythmConsistency: 0,
      modifierFrequency: 0,
      capitalFrequency: 0,
      punctuationFrequency: 0,
      burstSpeed: 0
    };

    if (events.length < 2) return pattern;

    const intervals = events.slice(1).map((event, i) => event.timeSinceLast);
    pattern.timingPatterns = intervals;
    pattern.averageSpeed = intervals.reduce((a, b) => a + b, 0) / intervals.length;

    const mean = pattern.averageSpeed;
    const variance = intervals.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / intervals.length;
    pattern.rhythmConsistency = Math.sqrt(variance);

    const sortedIntervals = [...intervals].sort((a, b) => a - b);
    const burstCount = Math.max(1, Math.floor(intervals.length * 0.2));
    pattern.burstSpeed = sortedIntervals.slice(0, burstCount).reduce((a, b) => a + b, 0) / burstCount;

    let currentWord = '';
    let totalWordLength = 0;
    let wordCount = 0;
    let modifierCount = 0;
    let capitalCount = 0;
    let punctuationCount = 0;

    events.forEach(event => {
      if (Object.values(event.modifiers).some(v => v)) {
        modifierCount++;
      }

      if (event.key.length === 1) {
        pattern.keyPressDistribution[event.key] = (pattern.keyPressDistribution[event.key] || 0) + 1;
        
        if (event.key.match(/[A-Z]/)) {
          capitalCount++;
        }

        if (event.key.match(/[.,!?;:'"]/)) {
          punctuationCount++;
        }

        if (event.key === ' ' || event.key === 'Enter') {
          if (currentWord.length > 0) {
            totalWordLength += currentWord.length;
            wordCount++;
            currentWord = '';
          }
        } else {
          currentWord += event.key;
        }
      }

      if (event.key === 'Backspace') {
        pattern.backspaceFrequency++;
        if (currentWord.length > 0) {
          currentWord = currentWord.slice(0, -1);
        }
      }

      Object.entries(event.modifiers).forEach(([key, value]) => {
        if (value) {
          pattern.modifierUsage[key] = (pattern.modifierUsage[key] || 0) + 1;
        }
      });
    });

    if (currentWord.length > 0) {
      totalWordLength += currentWord.length;
      wordCount++;
    }

    pattern.averageWordLength = wordCount > 0 ? totalWordLength / wordCount : 0;
    pattern.modifierFrequency = events.length > 0 ? modifierCount / events.length : 0;
    pattern.capitalFrequency = events.length > 0 ? capitalCount / events.length : 0;
    pattern.punctuationFrequency = events.length > 0 ? punctuationCount / events.length : 0;

    return pattern;
  };

  const comparePatterns = (pattern1: TypingPattern, pattern2: TypingPattern): number => {
    const weights = {
      speed: 0.2,
      wordLength: 0.15,
      rhythm: 0.15,
      modifiers: 0.15,
      capitals: 0.15,
      punctuation: 0.1,
      burst: 0.1
    };

    const speedDiff = Math.abs(pattern1.averageSpeed - pattern2.averageSpeed);
    const speedSimilarity = Math.max(0, 1 - speedDiff / 200);

    const wordLengthDiff = Math.abs(pattern1.averageWordLength - pattern2.averageWordLength);
    const wordLengthSimilarity = Math.max(0, 1 - wordLengthDiff / 5);

    const rhythmDiff = Math.abs(pattern1.rhythmConsistency - pattern2.rhythmConsistency);
    const rhythmSimilarity = Math.max(0, 1 - rhythmDiff / 100);

    const modifierDiff = Math.abs(pattern1.modifierFrequency - pattern2.modifierFrequency);
    const modifierSimilarity = Math.max(0, 1 - modifierDiff);

    const capitalDiff = Math.abs(pattern1.capitalFrequency - pattern2.capitalFrequency);
    const capitalSimilarity = Math.max(0, 1 - capitalDiff);

    const punctuationDiff = Math.abs(pattern1.punctuationFrequency - pattern2.punctuationFrequency);
    const punctuationSimilarity = Math.max(0, 1 - punctuationDiff);

    const burstDiff = Math.abs(pattern1.burstSpeed - pattern2.burstSpeed);
    const burstSimilarity = Math.max(0, 1 - burstDiff / 200);

    return (
      speedSimilarity * weights.speed +
      wordLengthSimilarity * weights.wordLength +
      rhythmSimilarity * weights.rhythm +
      modifierSimilarity * weights.modifiers +
      capitalSimilarity * weights.capitals +
      punctuationSimilarity * weights.punctuation +
      burstSimilarity * weights.burst
    );
  };

  const predictUser = async () => {
    if (keyEvents.length < MINIMUM_SAMPLE_SIZE) {
      setPredictionResult(`Need at least ${MINIMUM_SAMPLE_SIZE} keystrokes for accurate prediction`);
      return;
    }

    setIsGenerating(true);
    
    await new Promise(resolve => setTimeout(resolve, 1500));

    const currentPattern = calculateTypingPattern(keyEvents);
    let bestMatch: { profile: UserProfile; similarity: number } | null = null;

    userProfiles.forEach(profile => {
      const similarity = comparePatterns(currentPattern, profile.pattern);
      if (!bestMatch || similarity > bestMatch.similarity) {
        bestMatch = { profile, similarity: similarity };
      }
    });

    if (bestMatch && bestMatch.similarity > 0.2) {
      const result = `${bestMatch.profile.firstName} ${bestMatch.profile.lastName}`;
      const confidence = bestMatch.similarity;
      const isCorrectMatch = expectedProfile === result;

      const patternStats = [
        `Average Speed: ${currentPattern.averageSpeed.toFixed(2)}ms`,
        `Rhythm Consistency: ${currentPattern.rhythmConsistency.toFixed(2)}`,
        `Burst Speed: ${currentPattern.burstSpeed.toFixed(2)}ms`,
        `Modifier Usage: ${(currentPattern.modifierFrequency * 100).toFixed(1)}%`,
        `Capital Letters: ${(currentPattern.capitalFrequency * 100).toFixed(1)}%`,
        `Punctuation: ${(currentPattern.punctuationFrequency * 100).toFixed(1)}%`,
        `Average Word Length: ${currentPattern.averageWordLength.toFixed(1)} chars`
      ].join('\n');
      
      setPredictionResult(`
        🎯 Predicted User: ${result}
        Confidence: ${(confidence * 100).toFixed(1)}%
        ${confidence > 0.7 ? '✅ High confidence match!' : '⚠️ Low confidence match'}
        ${expectedProfile ? `Match Result: ${isCorrectMatch ? '✅ Correct!' : '❌ Incorrect'}` : ''}

        📊 Typing Pattern Analysis:
        ${patternStats}
      `);

      setPredictionHistory(prev => [...prev, {
        timestamp: Date.now(),
        actualUser: expectedProfile || 'Unknown',
        predictedUser: result,
        confidence: confidence,
        correct: expectedProfile ? isCorrectMatch : false,
        device: bestMatch.profile.device
      }]);
    } else {
      setPredictionResult("❌ No confident match found");
    }

    setIsGenerating(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const now = Date.now();
    if (!startTime) setStartTime(now);

    const keyEvent: KeyEvent = {
      key: e.key,
      code: e.code,
      timestamp: now,
      timeSinceLast: lastKeyTime ? now - lastKeyTime : 0,
      modifiers: {
        ctrl: e.ctrlKey,
        alt: e.altKey,
        shift: e.shiftKey,
        meta: e.metaKey,
      }
    };

    setLastKeyTime(now);
    setKeyEvents(prev => [...prev, keyEvent]);
  };

  const createNewProfile = () => {
    if (!firstName || !lastName || keyEvents.length < MINIMUM_SAMPLE_SIZE) return;

    const newProfile: UserProfile = {
      id: Date.now().toString(),
      firstName,
      lastName,
      samples: [keyEvents],
      pattern: calculateTypingPattern(keyEvents),
      createdAt: Date.now(),
      device: selectedDevice
    };

    setUserProfiles(prev => [...prev, newProfile]);
    setFirstName('');
    setLastName('');
    resetState();
    setMode('predict');
  };

  const deleteProfile = (id: string) => {
    setUserProfiles(prev => prev.filter(p => p.id !== id));
  };

  const resetHistory = () => {
    setPredictionHistory([]);
    setPredictionResult(null);
  };

  const switchMode = (newMode: Mode) => {
    setMode(newMode);
    resetState();
    setExpectedProfile(null);
  };

  const HowItWorks = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">How TypeWho Works</h2>
          <button
            onClick={() => setShowHowItWorks(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={24} />
          </button>
        </div>
        <div className="prose">
          <h3>Typing Pattern Analysis</h3>
          <p>
            TypeWho uses advanced pattern recognition to analyze your typing behavior across multiple dimensions:
          </p>
          <ul>
            <li>Typing speed and rhythm</li>
            <li>Key press timing patterns</li>
            <li>Use of modifier keys (Shift, Ctrl, etc.)</li>
            <li>Capitalization and punctuation habits</li>
            <li>Word length patterns</li>
          </ul>
          <h3>Creating a Profile</h3>
          <p>
            To create a profile, type at least {MINIMUM_SAMPLE_SIZE} characters. The system will analyze your typing
            pattern and save it for future comparison.
          </p>
          <h3>Prediction</h3>
          <p>
            When predicting a user, TypeWho compares the current typing pattern against all saved profiles,
            calculating a similarity score based on multiple factors.
          </p>
          <h3>Accuracy</h3>
          <p>
            The system provides confidence scores with each prediction. Scores above 70% indicate a high-confidence
            match, while lower scores suggest more uncertainty.
          </p>
        </div>
      </motion.div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Keyboard className="w-10 h-10 text-indigo-600" />
            <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-transparent bg-clip-text">
              TypeWho?
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex gap-2">
              <button
                onClick={() => switchMode('create')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  mode === 'create'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                Create Profile
              </button>
              <button
                onClick={() => switchMode('predict')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  mode === 'predict'
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
                disabled={userProfiles.length === 0}
              >
                Predict User
              </button>
            </div>
            <button
              onClick={() => setShowHowItWorks(true)}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-800"
            >
              <HelpCircle size={20} />
              How it works
            </button>
          </div>
        </div>

        <div className="grid gap-8">
          {/* Input Section */}
          <div className="bg-white rounded-xl shadow-xl p-6">
            <div className="flex items-center gap-3 mb-6">
              <Brain className="w-8 h-8 text-indigo-600" />
              <h2 className="text-2xl font-bold text-gray-800">
                {mode === 'create' ? 'Create New Profile' : 'Predict User'}
              </h2>
            </div>

            <div className="space-y-4">
              {mode === 'create' && (
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="First Name"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                  <input
                    type="text"
                    placeholder="Last Name"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
              )}

              {mode === 'predict' && userProfiles.length > 0 && (
                <select
                  value={expectedProfile || ''}
                  onChange={(e) => setExpectedProfile(e.target.value || null)}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  <option value="">Select expected user...</option>
                  {userProfiles.map(profile => (
                    <option key={profile.id} value={`${profile.firstName} ${profile.lastName}`}>
                      {profile.firstName} {profile.lastName}
                    </option>
                  ))}
                </select>
              )}

              <div className="relative">
                <textarea
                  ref={textAreaRef}
                  placeholder={
                    mode === 'create'
                      ? "Type something to create your typing profile..."
                      : "Type something to identify yourself..."
                  }
                  onKeyDown={handleKeyDown}
                  className="w-full h-32 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
                <div className="absolute bottom-2 right-2 text-sm text-gray-500">
                  {keyEvents.length}/{MINIMUM_SAMPLE_SIZE} keystrokes
                </div>
              </div>

              <div className="flex gap-4">
                {mode === 'create' ? (
                  <button
                    onClick={createNewProfile}
                    disabled={keyEvents.length < MINIMUM_SAMPLE_SIZE || !firstName || !lastName}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Save size={20} />
                    Save Profile
                  </button>
                ) : (
                  <button
                    onClick={predictUser}
                    disabled={keyEvents.length < MINIMUM_SAMPLE_SIZE}
                    className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <PlayCircle size={20} />
                    Predict User
                  </button>
                )}
              </div>
            </div>

            {isGenerating && (
              <div className="flex justify-center mt-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
              </div>
            )}

            {predictionResult && (
              <div className="relative p-4 bg-gray-50 rounded-lg mt-4 whitespace-pre-line">
                {predictionResult}
                <MatchMeter confidence={predictionHistory[predictionHistory.length - 1]?.confidence || 0} />
                {predictionHistory[predictionHistory.length - 1]?.correct && <SparkleEffect />}
              </div>
            )}
          </div>

          {/* Profiles Section */}
          <div className="bg-white rounded-xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Users className="w-8 h-8 text-indigo-600" />
                <h2 className="text-2xl font-bold text-gray-800">Saved Profiles</h2>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={resetHistory}
                  className="flex items-center gap-1 px-3 py-1 text-gray-600 hover:text-gray-800"
                >
                  <RotateCcw size={16} /> Reset History
                </button>
              </div>
            </div>

            {userProfiles.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <AlertTriangle className="w-12 h-12 mx-auto mb-4" />
                <p>No profiles yet. Create one by typing and saving a pattern.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {userProfiles.map(profile => (
                  <div key={profile.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <h3 className="font-semibold">{profile.firstName} {profile.lastName}</h3>
                      <p className="text-sm text-gray-500">Created {new Date(profile.createdAt).toLocaleDateString()}</p>
                    </div>
                    <button
                      onClick={() => deleteProfile(profile.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <AnimatePresence>
          {showHowItWorks && <HowItWorks />}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default App;