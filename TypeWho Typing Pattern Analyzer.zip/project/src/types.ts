export interface KeyEvent {
  key: string;
  code: string;
  timestamp: number;
  timeSinceLast: number;
  modifiers: {
    ctrl: boolean;
    alt: boolean;
    shift: boolean;
    meta: boolean;
  };
}

export interface TypingPattern {
  averageSpeed: number;
  keyPressDistribution: { [key: string]: number };
  modifierUsage: { [key: string]: number };
  timingPatterns: number[];
  specialKeyFrequency: { [key: string]: number };
  backspaceFrequency: number;
  averageWordLength: number;
  rhythmConsistency: number;
  modifierFrequency: number;
  capitalFrequency: number;
  punctuationFrequency: number;
  burstSpeed: number;
}

export interface PredictionHistory {
  timestamp: number;
  actualUser: string;
  predictedUser: string;
  confidence: number;
  correct: boolean;
}