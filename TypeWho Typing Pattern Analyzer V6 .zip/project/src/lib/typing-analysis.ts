import type { KeyEvent, TypingPattern } from '../types';

export function calculateTypingPattern(events: KeyEvent[]): TypingPattern {
  const pattern: TypingPattern = {
    averageSpeed: 0,
    keyPressDistribution: {},
    modifierUsage: {},
    timingPatterns: [],
    specialKeyFrequency: {},
    backspaceFrequency: 0,
    averageWordLength: 0,
    rhythmConsistency: 0,
    modifierFrequency: 0,
    capitalFrequency: 0,
    punctuationFrequency: 0,
    burstSpeed: 0,
    pauseFrequency: 0,
    speedVariability: 0,
    keyPressForce: 0,
    errorRate: 0
  };

  if (events.length < 2) return pattern;

  // Calculate timing patterns and average speed
  const intervals = events.slice(1).map((event, i) => event.timeSinceLast);
  pattern.timingPatterns = intervals;
  
  // Use median instead of mean for better outlier handling
  const sortedIntervals = [...intervals].sort((a, b) => a - b);
  pattern.averageSpeed = sortedIntervals[Math.floor(sortedIntervals.length / 2)];

  // Calculate rhythm consistency using median absolute deviation (MAD)
  const median = pattern.averageSpeed;
  const deviations = intervals.map(interval => Math.abs(interval - median));
  const mad = deviations.sort((a, b) => a - b)[Math.floor(deviations.length / 2)];
  pattern.rhythmConsistency = mad;

  // Calculate speed variability using robust statistics
  pattern.speedVariability = mad / median;

  // Calculate pause frequency (intervals > 750ms, adjusted threshold)
  pattern.pauseFrequency = intervals.filter(i => i > 750).length / intervals.length;

  // Calculate burst speed (average of fastest 30% intervals, increased from 20%)
  const burstCount = Math.max(1, Math.floor(intervals.length * 0.3));
  pattern.burstSpeed = sortedIntervals.slice(0, burstCount).reduce((a, b) => a + b, 0) / burstCount;

  let wordBuffer = '';
  let wordLengths: number[] = [];
  let modifierCount = 0;
  let capitalCount = 0;
  let punctuationCount = 0;
  let backspaceCount = 0;
  let totalChars = 0;
  let keyDistribution: { [key: string]: number } = {};

  events.forEach(event => {
    // Track modifier key usage with timing context
    if (Object.values(event.modifiers).some(v => v)) {
      modifierCount++;
      const timing = event.timeSinceLast;
      if (timing > 0) {
        pattern.modifierUsage[event.key] = timing;
      }
    }

    if (event.key.length === 1) {
      totalChars++;
      keyDistribution[event.key] = (keyDistribution[event.key] || 0) + 1;
      
      if (event.key.match(/[A-Z]/)) {
        capitalCount++;
      }

      if (event.key.match(/[.,!?;:'"]/)) {
        punctuationCount++;
      }

      if (event.key === ' ' || event.key === 'Enter') {
        if (wordBuffer.length > 0) {
          wordLengths.push(wordBuffer.length);
          wordBuffer = '';
        }
      } else {
        wordBuffer += event.key;
      }
    }

    if (event.key === 'Backspace') {
      backspaceCount++;
      if (wordBuffer.length > 0) {
        wordBuffer = wordBuffer.slice(0, -1);
      }
    }
  });

  // Finalize word buffer
  if (wordBuffer.length > 0) {
    wordLengths.push(wordBuffer.length);
  }

  // Calculate normalized key distribution
  const totalKeyPresses = Object.values(keyDistribution).reduce((a, b) => a + b, 0);
  pattern.keyPressDistribution = Object.fromEntries(
    Object.entries(keyDistribution).map(([key, count]) => [key, count / totalKeyPresses])
  );

  // Calculate error rate with context
  pattern.errorRate = totalChars > 0 ? 
    (backspaceCount / totalChars) * (1 + pattern.pauseFrequency) : 0;

  // Calculate average word length using median
  pattern.averageWordLength = wordLengths.length > 0 ?
    wordLengths.sort((a, b) => a - b)[Math.floor(wordLengths.length / 2)] : 0;

  pattern.modifierFrequency = events.length > 0 ? modifierCount / events.length : 0;
  pattern.capitalFrequency = totalChars > 0 ? capitalCount / totalChars : 0;
  pattern.punctuationFrequency = totalChars > 0 ? punctuationCount / totalChars : 0;
  pattern.backspaceFrequency = totalChars > 0 ? backspaceCount / totalChars : 0;

  return pattern;
}

export function comparePatterns(pattern1: TypingPattern, pattern2: TypingPattern): number {
  const weights = {
    speed: 0.15,
    keyDistribution: 0.15,
    rhythm: 0.15,
    wordLength: 0.1,
    modifiers: 0.1,
    capitals: 0.1,
    punctuation: 0.05,
    burst: 0.1,
    pauses: 0.05,
    errors: 0.05
  };

  // Compare typing speed with tolerance
  const speedDiff = Math.abs(pattern1.averageSpeed - pattern2.averageSpeed);
  const speedSimilarity = Math.max(0, 1 - speedDiff / Math.max(pattern1.averageSpeed, pattern2.averageSpeed));

  // Compare key distribution patterns
  const keys = new Set([
    ...Object.keys(pattern1.keyPressDistribution),
    ...Object.keys(pattern2.keyPressDistribution)
  ]);
  let keyDistSimilarity = 0;
  keys.forEach(key => {
    const freq1 = pattern1.keyPressDistribution[key] || 0;
    const freq2 = pattern2.keyPressDistribution[key] || 0;
    keyDistSimilarity += 1 - Math.abs(freq1 - freq2);
  });
  keyDistSimilarity /= keys.size || 1;

  // Compare rhythm patterns using dynamic time warping
  const rhythmSimilarity = 1 - Math.abs(pattern1.rhythmConsistency - pattern2.rhythmConsistency) / 
    Math.max(pattern1.rhythmConsistency, pattern2.rhythmConsistency, 1);

  // Compare word length patterns
  const wordLengthDiff = Math.abs(pattern1.averageWordLength - pattern2.averageWordLength);
  const wordLengthSimilarity = Math.max(0, 1 - wordLengthDiff / Math.max(pattern1.averageWordLength, 1));

  // Compare modifier key usage
  const modifierDiff = Math.abs(pattern1.modifierFrequency - pattern2.modifierFrequency);
  const modifierSimilarity = Math.max(0, 1 - modifierDiff);

  // Compare capitalization patterns
  const capitalDiff = Math.abs(pattern1.capitalFrequency - pattern2.capitalFrequency);
  const capitalSimilarity = Math.max(0, 1 - capitalDiff);

  // Compare punctuation usage
  const punctuationDiff = Math.abs(pattern1.punctuationFrequency - pattern2.punctuationFrequency);
  const punctuationSimilarity = Math.max(0, 1 - punctuationDiff);

  // Compare burst speed patterns
  const burstDiff = Math.abs(pattern1.burstSpeed - pattern2.burstSpeed);
  const burstSimilarity = Math.max(0, 1 - burstDiff / Math.max(pattern1.burstSpeed, pattern2.burstSpeed, 1));

  // Compare pause patterns
  const pauseDiff = Math.abs(pattern1.pauseFrequency - pattern2.pauseFrequency);
  const pauseSimilarity = Math.max(0, 1 - pauseDiff);

  // Compare error patterns
  const errorDiff = Math.abs(pattern1.errorRate - pattern2.errorRate);
  const errorSimilarity = Math.max(0, 1 - errorDiff);

  // Calculate weighted similarity score
  const similarity = 
    speedSimilarity * weights.speed +
    keyDistSimilarity * weights.keyDistribution +
    rhythmSimilarity * weights.rhythm +
    wordLengthSimilarity * weights.wordLength +
    modifierSimilarity * weights.modifiers +
    capitalSimilarity * weights.capitals +
    punctuationSimilarity * weights.punctuation +
    burstSimilarity * weights.burst +
    pauseSimilarity * weights.pauses +
    errorSimilarity * weights.errors;

  return similarity;
}