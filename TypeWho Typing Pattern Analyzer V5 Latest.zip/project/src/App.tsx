import React, { useState, useRef, useMemo } from 'react';
import { Save, Trash2, BarChart2, Keyboard, UserCircle2, Users, Brain, PlayCircle, RotateCcw, AlertTriangle, HelpCircle, Sparkles, X, PieChart, TrendingUp, Shield, UserCheck, Clock, Target, Percent, Home, ChevronRight, Lock, Lock as LockOpen, Zap, Fingerprint, Key, Cpu } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { calculateTypingPattern, comparePatterns } from './lib/typing-analysis';
import type { KeyEvent, TypingPattern, PredictionHistory, UserProfile, UserSession } from './types';

const MINIMUM_SAMPLE_SIZE = 75;
const HIGH_CONFIDENCE_THRESHOLD = 0.85;
const POSSIBLE_MATCH_THRESHOLD = 0.75;

const TYPING_TIPS = [
  "💡 Type naturally with your usual rhythm and style",
  "💡 Include punctuation and capitals as you normally would",
  "💡 Write at least a few sentences for better accuracy"
].join('\n');

type Mode = 'create' | 'predict';

function App() {
  const [mode, setMode] = useState<Mode>('create');
  const [showDashboard, setShowDashboard] = useState(false);
  const [keyEvents, setKeyEvents] = useState<KeyEvent[]>([]);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [lastKeyTime, setLastKeyTime] = useState<number | null>(null);
  const [userProfiles, setUserProfiles] = useState<UserProfile[]>([]);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [predictionResult, setPredictionResult] = useState<React.ReactNode | null>(null);
  const [predictionHistory, setPredictionHistory] = useState<PredictionHistory[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showHowItWorks, setShowHowItWorks] = useState(false);
  const textAreaRef = useRef<HTMLTextAreaElement>(null);
  const [lastKeystrokeTime, setLastKeystrokeTime] = useState<number | null>(null);
  const [typingSpeed, setTypingSpeed] = useState<number>(0);

  // Analytics calculations
  const analytics = useMemo(() => {
    const totalPredictions = predictionHistory.length;
    const successfulPredictions = predictionHistory.filter(p => p.confidence >= HIGH_CONFIDENCE_THRESHOLD).length;
    const accurateMatches = predictionHistory.filter(p => p.correct).length;
    const recentPredictions = predictionHistory.slice(-10);
    const recentAccuracy = recentPredictions.length ? 
      (recentPredictions.filter(p => p.correct).length / recentPredictions.length) * 100 : 0;
    
    return {
      totalAttempts: totalPredictions,
      successRate: totalPredictions ? (successfulPredictions / totalPredictions) * 100 : 0,
      accuracy: totalPredictions ? (accurateMatches / totalPredictions) * 100 : 0,
      averageConfidence: totalPredictions ? 
        predictionHistory.reduce((acc, curr) => acc + curr.confidence, 0) / totalPredictions * 100 : 0,
      recentAccuracy
    };
  }, [predictionHistory]);

  const resetState = () => {
    if (textAreaRef.current) {
      textAreaRef.current.value = '';
    }
    setKeyEvents([]);
    setStartTime(null);
    setLastKeyTime(null);
    setTypingSpeed(0);
    setLastKeystrokeTime(null);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const now = Date.now();
    if (!startTime) setStartTime(now);

    const keyEvent: KeyEvent = {
      key: e.key,
      code: e.code,
      timestamp: now,
      timeSinceLast: lastKeyTime ? now - lastKeyTime : 0,
      modifiers: {
        ctrl: e.ctrlKey,
        alt: e.altKey,
        shift: e.shiftKey,
        meta: e.metaKey,
      }
    };

    if (lastKeystrokeTime) {
      const timeDiff = now - lastKeystrokeTime;
      const instantSpeed = 60000 / timeDiff;
      setTypingSpeed(prev => prev * 0.7 + instantSpeed * 0.3);
    }
    setLastKeystrokeTime(now);
    setLastKeyTime(now);
    setKeyEvents(prev => [...prev, keyEvent]);
  };

  const predictUser = async () => {
    if (keyEvents.length < MINIMUM_SAMPLE_SIZE) {
      setPredictionResult(
        <div className="text-red-600 text-center">
          Need at least {MINIMUM_SAMPLE_SIZE} keystrokes for accurate prediction
        </div>
      );
      return;
    }

    setIsGenerating(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    const currentPattern = calculateTypingPattern(keyEvents);
    let bestMatch: { profile: UserProfile; similarity: number } | null = null;

    userProfiles.forEach(profile => {
      const similarity = comparePatterns(currentPattern, profile.pattern);
      if (!bestMatch || similarity > bestMatch.similarity) {
        bestMatch = { profile, similarity: similarity };
      }
    });

    if (bestMatch) {
      const result = `${bestMatch.profile.firstName} ${bestMatch.profile.lastName}`;
      const confidence = bestMatch.similarity;
      const isHighConfidence = confidence >= HIGH_CONFIDENCE_THRESHOLD;
      
      if (isHighConfidence) {
        setPredictionResult(
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative bg-white rounded-lg shadow-sm border border-green-200 p-4 max-w-md mx-auto"
          >
            <button 
              onClick={() => setPredictionResult(null)}
              className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
            >
              <X size={16} />
            </button>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <UserCheck className="w-4 h-4 text-green-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Match Found!</h2>
                <p className="text-xs text-gray-500">High confidence identification</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">User:</span>
                <span className="font-medium text-gray-900">{result}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Confidence:</span>
                <span className="font-medium text-green-600">{(confidence * 100).toFixed(1)}%</span>
              </div>
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-500 rounded-full"
                  style={{ width: `${confidence * 100}%` }}
                />
              </div>
            </div>
          </motion.div>
        );
      } else {
        setPredictionResult(
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative bg-white rounded-lg shadow-sm border border-red-200 p-4 max-w-md mx-auto"
          >
            <button 
              onClick={() => setPredictionResult(null)}
              className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
            >
              <X size={16} />
            </button>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 text-red-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900">No Match Found</h2>
                <p className="text-xs text-gray-500">Confidence below threshold</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Confidence:</span>
                <span className="font-medium text-red-600">{(confidence * 100).toFixed(1)}%</span>
              </div>
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-red-500 rounded-full"
                  style={{ width: `${confidence * 100}%` }}
                />
              </div>
            </div>
          </motion.div>
        );
      }

      setPredictionHistory(prev => [...prev, {
        predictedUser: result,
        confidence: confidence,
        correct: isHighConfidence,
        timestamp: Date.now()
      }]);
    }

    setIsGenerating(false);
    resetState();
  };

  const deleteProfile = (id: string) => {
    setUserProfiles(prev => prev.filter(p => p.id !== id));
  };

  const createNewProfile = () => {
    if (!firstName || !lastName || keyEvents.length < MINIMUM_SAMPLE_SIZE) return;

    const newProfile: UserProfile = {
      id: Date.now().toString(),
      firstName,
      lastName,
      samples: [keyEvents],
      pattern: calculateTypingPattern(keyEvents),
      createdAt: Date.now(),
      role: 'user'
    };

    setUserProfiles(prev => [...prev, newProfile]);
    setFirstName('');
    setLastName('');
    resetState();
    // Auto-switch to predict mode after creating a profile
    setMode('predict');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto">
          <div className="h-16 grid grid-cols-3 items-center px-4">
            {/* Left: Logo */}
            <div className="flex items-center gap-2">
              <Keyboard className="w-8 h-8 text-indigo-600" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-transparent bg-clip-text">
                TypeWho?
              </h1>
            </div>

            {/* Center: Dashboard Toggle */}
            <div className="flex justify-center">
              <button
                onClick={() => setShowDashboard(!showDashboard)}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  showDashboard 
                    ? 'bg-indigo-600 text-white shadow-lg scale-105' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <BarChart2 size={20} />
              </button>
            </div>

            {/* Right: Help */}
            <div className="flex justify-end">
              <button
                onClick={() => setShowHowItWorks(true)}
                className="w-10 h-10 rounded-full flex items-center justify-center bg-gray-100 text-gray-600 hover:bg-gray-200"
              >
                <HelpCircle size={20} />
              </button>
            </div>
          </div>

          {/* Collapsible Dashboard */}
          <AnimatePresence>
            {showDashboard && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="border-t border-gray-200 overflow-hidden"
              >
                <div className="p-4">
                  <div className="grid grid-cols-4 gap-4">
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 }}
                      className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Target className="w-5 h-5 text-indigo-600" />
                        <h3 className="font-medium">Total Attempts</h3>
                      </div>
                      <p className="text-2xl font-bold">{analytics.totalAttempts}</p>
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                      className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <UserCheck className="w-5 h-5 text-green-600" />
                        <h3 className="font-medium">Success Rate</h3>
                      </div>
                      <p className="text-2xl font-bold">{analytics.successRate.toFixed(1)}%</p>
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                        <h3 className="font-medium">Accuracy</h3>
                      </div>
                      <p className="text-2xl font-bold">{analytics.accuracy.toFixed(1)}%</p>
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                      className="bg-white p-4 rounded-lg shadow-sm border border-gray-200"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Percent className="w-5 h-5 text-purple-600" />
                        <h3 className="font-medium">Avg. Confidence</h3>
                      </div>
                      <p className="text-2xl font-bold">{analytics.averageConfidence.toFixed(1)}%</p>
                    </motion.div>
                  </div>

                  {/* User Profiles Section */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="mt-4 bg-white p-6 rounded-xl shadow-sm border border-gray-200"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-indigo-100 rounded-lg">
                          <Users className="w-6 h-6 text-indigo-600" />
                        </div>
                        <h3 className="text-lg font-semibold">User Profiles</h3>
                      </div>
                      <span className="text-sm text-gray-500">{userProfiles.length} profiles</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      {userProfiles.map(profile => (
                        <motion.div
                          key={profile.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-gray-50 p-4 rounded-lg border border-gray-100"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="font-medium">{profile.firstName} {profile.lastName}</h3>
                                {profile.role === 'admin' && (
                                  <span className="bg-indigo-100 text-indigo-800 text-xs px-2 py-0.5 rounded-full">
                                    Admin
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-gray-500">{new Date(profile.createdAt).toLocaleDateString()}</p>
                            </div>
                            <button
                              onClick={() => deleteProfile(profile.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>

                  {/* System Performance Widget */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 }}
                    className="mt-4 bg-gradient-to-br from-indigo-500 to-purple-600 p-6 rounded-xl text-white"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-white/10 rounded-lg">
                          <Zap className="w-6 h-6" />
                        </div>
                        <h3 className="text-lg font-semibold">Recent System Performance</h3>
                      </div>
                      <div className="flex items-center gap-2 text-white/80 text-sm">
                        <Clock size={16} />
                        <span>Last 10 predictions</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-white/80">
                          <Fingerprint size={16} />
                          <span>Recent Accuracy</span>
                        </div>
                        <p className="text-3xl font-bold">{analytics.recentAccuracy.toFixed(1)}%</p>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-white/80">
                          <Key size={16} />
                          <span>Active Profiles</span>
                        </div>
                        <p className="text-3xl font-bold">{userProfiles.length}</p>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-white/80">
                          <Cpu size={16} />
                          <span>System Load</span>
                        </div>
                        <p className="text-3xl font-bold">Optimal</p>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-2 gap-6 mb-8">
          <button
            onClick={() => setMode('create')}
            className={`p-6 rounded-xl transition-all ${
              mode === 'create'
                ? 'bg-indigo-600 text-white shadow-lg scale-105'
                : 'bg-white text-gray-600 hover:bg-gray-50'
            } border border-gray-200`}
          >
            <div className="flex items-center gap-3 mb-3">
              <UserCircle2 className={`w-8 h-8 ${mode === 'create' ? 'text-white' : 'text-indigo-600'}`} />
              <h2 className="text-xl font-bold">Create Profile</h2>
            </div>
            <p className={mode === 'create' ? 'text-indigo-100' : 'text-gray-500'}>
              Create a new typing profile to be identified later
            </p>
          </button>

          <button
            onClick={() => setMode('predict')}
            disabled={userProfiles.length === 0}
            className={`p-6 rounded-xl transition-all ${
              mode === 'predict'
                ? 'bg-purple-600 text-white shadow-lg scale-105'
                : 'bg-white text-gray-600 hover:bg-gray-50'
            } border border-gray-200 ${userProfiles.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <div className="flex items-center gap-3 mb-3">
              <Brain className={`w-8 h-8 ${mode === 'predict' ? 'text-white' : 'text-purple-600'}`} />
              <h2 className="text-xl font-bold">Predict User</h2>
            </div>
            <p className={mode === 'predict' ? 'text-purple-100' : 'text-gray-500'}>
              {userProfiles.length === 0
                ? 'Create a profile first to enable prediction'
                : 'Identify yourself based on your typing pattern'}
            </p>
          </button>
        </div>

        {predictionResult && (
          <div className="mb-6">
            {predictionResult}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="space-y-4">
            {mode === 'create' && (
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="First Name"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
                <input
                  type="text"
                  placeholder="Last Name"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
            )}

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium text-gray-700">Tips for Better Results</h3>
              </div>
              <div className="text-xs text-gray-500 whitespace-pre-line">
                {TYPING_TIPS}
              </div>
            </div>

            <div className="relative">
              <textarea
                ref={textAreaRef}
                placeholder={
                  mode === 'create'
                    ? "Start typing to create your profile..."
                    : "Start typing to identify yourself..."
                }
                onKeyDown={handleKeyDown}
                className="w-full h-32 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
              
              <div className="mt-2 relative">
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-indigo-500 to-purple-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${(keyEvents.length / MINIMUM_SAMPLE_SIZE) * 100}%` }}
                    transition={{ type: "spring", stiffness: 100 }}
                  />
                </div>
                <div className="flex justify-between items-center mt-2 text-sm text-gray-600">
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-2"
                  >
                    <Clock size={14} />
                    <span>{Math.round(typingSpeed)} CPM</span>
                  </motion.div>
                  <motion.div 
                    className="flex items-center gap-2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    <span>Keystrokes:</span>
                    <motion.span 
                      key={keyEvents.length}
                      initial={{ scale: 1.2, color: "#4F46E5" }}
                      animate={{ scale: 1, color: "#6B7280" }}
                      className="font-mono font-medium"
                    >
                      {keyEvents.length}/{MINIMUM_SAMPLE_SIZE}
                    </motion.span>
                  </motion.div>
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              {mode === 'create' ? (
                <button
                  onClick={createNewProfile}
                  disabled={keyEvents.length < MINIMUM_SAMPLE_SIZE || !firstName || !lastName}
                  className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Save size={20} />
                  Save Profile
                </button>
              ) : (
                <div className="flex gap-4">
                  <button
                    onClick={predictUser}
                    disabled={keyEvents.length < MINIMUM_SAMPLE_SIZE}
                    className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <PlayCircle size={20} />
                    Predict User
                  </button>
                  {predictionResult && (
                    <button
                      onClick={resetState}
                      className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                    >
                      <RotateCcw size={20} />
                      Try Again
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>

          {isGenerating && (
            <div className="flex justify-center mt-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          )}
        </div>
      </main>

      <AnimatePresence>
        {showHowItWorks && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">How TypeWho Works</h2>
                <button
                  onClick={() => setShowHowItWorks(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X size={24} />
                </button>
              </div>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Fingerprint className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Typing Pattern Analysis</h3>
                    <p className="text-gray-600">
                      TypeWho uses advanced pattern recognition to analyze your typing behavior across multiple dimensions:
                    </p>
                    <ul className="mt-2 space-y-1 text-gray-600">
                      <li className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-indigo-500" />
                        Typing speed and rhythm
                      </li>
                      <li className="flex items-center gap-2">
                        <Key className="w-4 h-4 text-indigo-500" />
                        Key press timing patterns
                      </li>
                      <li className="flex items-center gap-2">
                        <ChevronRight className="w-4 h-4 text-indigo-500" />
                        Use of modifier keys (Shift, Ctrl, etc.)
                      </li>
                      <li className="flex items-center gap-2">
                        <Lock className="w-4 h-4 text-indigo-500" />
                        Capitalization and punctuation habits
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink- shrink-0">
                    <Brain className="w-6 h-6 text-purple-600" />
                  </div>
                   <div>
                    <h3 className="text-lg font-semibold mb-2">Creating a Profile</h3>
                    <p className="text-gray-600">
                      To create a profile, type at least {MINIMUM_SAMPLE_SIZE} characters. The system will analyze your typing
                      pattern and save it for future comparison. Each profile is unique to your typing style and habits.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Shield className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Prediction Process</h3>
                    <p className="text-gray-600">
                      When predicting a user, TypeWho compares the current typing pattern against all saved profiles,
                      calculating a similarity score based on multiple factors. The system uses advanced algorithms to
                      ensure accurate identification.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Target className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">Accuracy Metrics</h3>
                    <p className="text-gray-600">
                      The system provides confidence scores with each prediction:
                    </p>
                    <ul className="mt-2 space-y-2">
                      <li className="flex items-center gap-2 text-green-600">
                        <UserCheck className="w-4 h-4" />
                        Above {(HIGH_CONFIDENCE_THRESHOLD * 100).toFixed(0)}%: High-confidence match
                      </li>
                      <li className="flex items-center gap-2 text-red-600">
                        <AlertTriangle className="w-4 h-4" />
                        Below {(HIGH_CONFIDENCE_THRESHOLD * 100).toFixed(0)}%: No match
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;